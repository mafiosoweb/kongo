<?php /*
Magento Module developed by NoStress Commerce

 NOTICE OF LICENSE

 This source file is subject to the Open Software License (OSL 3.0)
 that is bundled with this package in the file LICENSE.txt.
 It is also available through the world-wide-web at this URL:
 http://opensource.org/licenses/osl-3.0.php
 If you did of the license and are unable to
 obtain it through the world-wide-web, please send an email
 to info@nostresscommerce.cz so we can send you a copy immediately.

 @copyright Copyright (c) 2015 NoStress Commerce (http://www.nostresscommerce.cz)

*/
namespace Nostress\Koongo\Model\ResourceModel;${"\x47\x4cO\x42\x41LS"}["\x71\x69\x70\x70in\x79\x6a"]="\x73e\x6c\x65\x63\x74";${"GL\x4fB\x41\x4c\x53"}["\x6f\x6b\x77y\x6ff\x61s\x63\x78g"]="u\x73\x65\x54\x72\x61\x6e\x73\x61\x63t\x69\x6f\x6e";${"\x47LOB\x41\x4c\x53"}["\x6ei\x71\x72\x6b\x78\x66\x6e"]="q\x75e\x72\x79\x53\x74\x72i\x6eg";abstract class AbstractResourceModel extends\Magento\Framework\Model\ResourceModel\Db\AbstractDb{const TIME="\x74\x69\x6de";const DATE="\x64ate";const DATE_TIME="\x64a\x74e_\x74\x69me";protected function runQuery($queryString,$tableName="",$message="",$useTransaction=true){${"G\x4cO\x42\x41\x4c\x53"}["kf\x6c\x61kee\x69\x74\x6a"]="\x71\x75\x65r\x79\x53tr\x69n\x67";${"\x47\x4c\x4f\x42\x41\x4c\x53"}["\x64\x7ae\x68\x66\x6d\x71\x6f\x67\x6f"]="m\x65\x73\x73\x61\x67\x65";if(!empty(${${"\x47\x4cOB\x41\x4c\x53"}["\x64\x7a\x65h\x66\x6dqog\x6f"]})){$this->helper->log("\x54ab\x6ce:\x20{$tableName}");${"G\x4c\x4fB\x41\x4cS"}["\x6b\x70\x71\x71l\x64fx"]="\x6d\x65\x73\x73a\x67e";$this->helper->log(${${"\x47L\x4f\x42A\x4c\x53"}["k\x70qq\x6cdfx"]});$this->helper->log(base64_encode(${${"G\x4cO\x42AL\x53"}["n\x69q\x72k\x78\x66\x6e"]}));}if(!isset(${${"\x47\x4cOBA\x4c\x53"}["\x6b\x66\x6c\x61ke\x65\x69\x74j"]})||${${"\x47\x4c\x4f\x42A\x4cS"}["n\x69q\x72k\x78\x66n"]}=="")return$this;if(${${"\x47\x4c\x4fB\x41LS"}["\x6fk\x77\x79of\x61\x73\x63\x78g"]})$this->transactionManager->start($this->getConnection());try{${"\x47\x4cOB\x41\x4cS"}["\x62vfoh\x6ek"]="que\x72\x79St\x72\x69\x6e\x67";$rusxxhfj="u\x73eT\x72\x61\x6esa\x63\x74\x69on";$this->getConnection()->query(${${"G\x4cO\x42\x41\x4c\x53"}["b\x76\x66\x6f\x68nk"]});if(${$rusxxhfj})$this->commit();}catch(\Exception$e){$apeshgi="\x65";$jtothvytsyy="\x75\x73\x65\x54\x72a\x6es\x61\x63\x74\x69on";if(${$jtothvytsyy})$this->transactionManager->rollBack();throw${$apeshgi};}return$this;}protected function runSelectQuery($select,$tableName="",$message=""){${"\x47L\x4fB\x41L\x53"}["\x6d\x66\x73\x71\x79\x6d\x63\x79\x6d\x61\x76\x77"]="\x6d\x65\x73s\x61\x67\x65";if(!empty(${${"\x47\x4cO\x42\x41\x4c\x53"}["\x6d\x66s\x71\x79\x6d\x63\x79\x6d\x61\x76\x77"]})){$zndoapyfz="\x71\x75\x65\x72\x79\x53t\x72in\x67";${$zndoapyfz}=$select->__toString();${"\x47\x4cO\x42\x41\x4cS"}["\x72\x69s\x64\x69\x6du"]="\x6des\x73ag\x65";$ztkajqctmg="q\x75eryStri\x6eg";$this->helper->log("T\x61\x62le: {$tableName}");$this->helper->log(${${"\x47LO\x42\x41\x4c\x53"}["\x72\x69\x73d\x69\x6d\x75"]});$this->helper->log(base64_encode(${$ztkajqctmg}));}return$this->getConnection()->fetchAll(${${"\x47\x4c\x4fB\x41\x4cS"}["\x71\x69\x70piny\x6a"]});}protected function runOneRowSelectQuery($queryString){return$this->getConnection()->fetchRow(${${"\x47\x4cO\x42\x41\x4c\x53"}["\x6ei\x71\x72\x6b\x78\x66n"]});}}
?>
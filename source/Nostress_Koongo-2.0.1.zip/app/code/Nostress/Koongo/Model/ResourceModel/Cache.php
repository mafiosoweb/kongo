<?php /*
Magento Module developed by NoStress Commerce

 NOTICE OF LICENSE

 This source file is subject to the Open Software License (OSL 3.0)
 that is bundled with this package in the file LICENSE.txt.
 It is also available through the world-wide-web at this URL:
 http://opensource.org/licenses/osl-3.0.php
 If you did of the license and are unable to
 obtain it through the world-wide-web, please send an email
 to info@nostresscommerce.cz so we can send you a copy immediately.

 @copyright Copyright (c) 2015 NoStress Commerce (http://www.nostresscommerce.cz)

*/
namespace Nostress\Koongo\Model\ResourceModel;${"G\x4cO\x42\x41\x4c\x53"}["\x62\x73\x70\x62\x63g\x78\x79ls"]="\x73ta\x74\x75s";${"\x47LO\x42\x41\x4c\x53"}["\x71\x6a\x66\x69lt"]="s\x74\x6f\x72e\x49\x64";class Cache extends\Nostress\Koongo\Model\ResourceModel\Data\Loader{const STARTED="\x73\x74\x61r\x74ed";const FINISHED="\x66\x69\x6e\x69\x73\x68\x65d";protected$_cacheName='';protected function defineColumns(){parent::defineColumns();}public function reload($storeId){$this->logStatus(self::STARTED,${${"\x47L\x4fBALS"}["\x71jf\x69l\x74"]});$wzxhyobdqcg="\x73tor\x65\x49\x64";$this->setStoreId(${$wzxhyobdqcg});$this->init();$this->reloadTable();$this->logStatus(self::FINISHED,${${"\x47\x4c\x4f\x42\x41\x4c\x53"}["\x71j\x66i\x6c\x74"]});}public function init(){$this->defineColumns();}protected function logStatus($status,$storeId){${"\x47L\x4fB\x41LS"}["xh\x6b\x6e\x68a"]="\x73\x74\x6fr\x65\x49\x64";$this->helper->log(__("%\x31 \x63a\x63\x68e relo\x61d \x68\x61\x73\x20%\x32 \x66or sto\x72\x65\x20#\x25\x33",$this->_cacheName,${${"G\x4c\x4f\x42\x41\x4cS"}["\x62\x73\x70\x62c\x67\x78\x79\x6c\x73"]},${${"\x47\x4c\x4fB\x41\x4c\x53"}["x\x68kn\x68\x61"]}));}public function getCacheColumns($type=null){if(!isset($this->_columns))$this->defineColumns();return array();}}
?>
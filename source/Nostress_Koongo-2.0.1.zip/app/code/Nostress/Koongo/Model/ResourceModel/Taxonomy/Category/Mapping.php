<?php /*
Magento Module developed by NoStress Commerce

 NOTICE OF LICENSE

 This source file is subject to the Open Software License (OSL 3.0)
 that is bundled with this package in the file LICENSE.txt.
 It is also available through the world-wide-web at this URL:
 http://opensource.org/licenses/osl-3.0.php
 If you did of the license and are unable to
 obtain it through the world-wide-web, please send an email
 to info@nostresscommerce.cz so we can send you a copy immediately.

 @copyright Copyright (c) 2015 NoStress Commerce (http://www.nostresscommerce.cz)

*/
namespace Nostress\Koongo\Model\ResourceModel\Taxonomy\Category;class Mapping extends\Nostress\Koongo\Model\ResourceModel\AbstractResourceModel{public function _construct(){$this->_init("n\x6fstres\x73_ko\x6f\x6eg\x6f\x5f\x74a\x78\x6fn\x6fmy_c\x61\x74\x65g\x6fr\x79\x5f\x6da\x70\x70i\x6eg","\x65nt\x69\x74y_i\x64");}}
?>
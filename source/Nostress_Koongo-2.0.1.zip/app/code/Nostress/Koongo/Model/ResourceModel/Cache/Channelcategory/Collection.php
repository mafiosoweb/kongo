<?php /*
Magento Module developed by NoStress Commerce

 NOTICE OF LICENSE

 This source file is subject to the Open Software License (OSL 3.0)
 that is bundled with this package in the file LICENSE.txt.
 It is also available through the world-wide-web at this URL:
 http://opensource.org/licenses/osl-3.0.php
 If you did of the license and are unable to
 obtain it through the world-wide-web, please send an email
 to info@nostresscommerce.cz so we can send you a copy immediately.

 @copyright Copyright (c) 2015 NoStress Commerce (http://www.nostresscommerce.cz)

*/
namespace Nostress\Koongo\Model\ResourceModel\Cache\Channelcategory;class Collection extends\Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection{protected$_idFieldName='product_id';protected function _construct(){$this->_init("Nos\x74\x72es\x73\\Ko\x6f\x6e\x67o\\Mo\x64\x65\x6c\\\x43\x61\x63he\\C\x68ann\x65\x6ccat\x65\x67or\x79","\x4eo\x73\x74\x72e\x73s\\K\x6f\x6fn\x67\x6f\x5cM\x6fd\x65\x6c\x5c\x52\x65\x73o\x75r\x63e\x4dodel\\\x43\x61ch\x65\x5c\x43\x68ann\x65lca\x74\x65go\x72\x79");}}
?>
<?php /*
Magento Module developed by NoStress Commerce

 NOTICE OF LICENSE

 This source file is subject to the Open Software License (OSL 3.0)
 that is bundled with this package in the file LICENSE.txt.
 It is also available through the world-wide-web at this URL:
 http://opensource.org/licenses/osl-3.0.php
 If you did of the license and are unable to
 obtain it through the world-wide-web, please send an email
 to info@nostresscommerce.cz so we can send you a copy immediately.

 @copyright Copyright (c) 2015 NoStress Commerce (http://www.nostresscommerce.cz)

*/
namespace Nostress\Koongo\Model\ResourceModel\Channel\Profile;class Collection extends\Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection{protected$_idFieldName='entity_id';protected function _construct(){$this->_init("\x4e\x6f\x73\x74r\x65s\x73\x5cKoo\x6e\x67\x6f\x5c\x4d\x6f\x64e\x6c\x5c\x43h\x61\x6enel\\Profi\x6c\x65","No\x73tress\x5cK\x6f\x6f\x6e\x67o\\\x4d\x6fdel\x5cR\x65s\x6f\x75\x72\x63\x65Model\\\x43h\x61nnel\x5c\x50r\x6f\x66\x69le");}}
?>
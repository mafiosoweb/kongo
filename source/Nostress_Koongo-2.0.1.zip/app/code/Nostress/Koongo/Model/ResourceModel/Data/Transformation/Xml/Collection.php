<?php /*
Magento Module developed by NoStress Commerce

 NOTICE OF LICENSE

 This source file is subject to the Open Software License (OSL 3.0)
 that is bundled with this package in the file LICENSE.txt.
 It is also available through the world-wide-web at this URL:
 http://opensource.org/licenses/osl-3.0.php
 If you did of the license and are unable to
 obtain it through the world-wide-web, please send an email
 to info@nostresscommerce.cz so we can send you a copy immediately.

 @copyright Copyright (c) 2015 NoStress Commerce (http://www.nostresscommerce.cz)

*/
namespace Nostress\Koongo\Model\ResourceModel\Data\Transformation\Xml;class Collection extends\Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection{protected function _construct(){$this->_init("Nos\x74\x72\x65\x73\x73\\\x4b\x6f\x6f\x6ego\\M\x6f\x64\x65l\x5cD\x61\x74a\\T\x72\x61\x6e\x73\x66o\x72\x6d\x61\x74ion\\\x58ml","\x4e\x6f\x73t\x72ess\\K\x6fong\x6f\\\x4d\x6f\x64e\x6c\x5c\x52\x65\x73o\x75\x72\x63eM\x6fde\x6c\x5cDat\x61\\Trans\x66\x6fr\x6datio\x6e\x5cX\x6dl");}}
?>
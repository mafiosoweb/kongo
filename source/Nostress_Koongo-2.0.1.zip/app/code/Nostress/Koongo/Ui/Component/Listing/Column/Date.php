<?php /*
Magento Module developed by NoStress Commerce

 NOTICE OF LICENSE

 This source file is subject to the Open Software License (OSL 3.0)
 that is bundled with this package in the file LICENSE.txt.
 It is also available through the world-wide-web at this URL:
 http://opensource.org/licenses/osl-3.0.php
 If you did of the license and are unable to
 obtain it through the world-wide-web, please send an email
 to info@nostresscommerce.cz so we can send you a copy immediately.

 @copyright Copyright (c) 2015 NoStress Commerce (http://www.nostresscommerce.cz)

*/
namespace Nostress\Koongo\Ui\Component\Listing\Column;${"\x47\x4c\x4fB\x41\x4c\x53"}["\x67\x65\x67\x67\x68\x71\x67\x62\x64"]="\x64\x61\x74\x61\x53o\x75r\x63e";${"G\x4c\x4fBA\x4cS"}["\x72\x62\x73\x73\x75\x6c\x72"]="\x75\x69\x43o\x6dpo\x6e\x65n\x74\x46a\x63to\x72\x79";${"GLO\x42AL\x53"}["\x79\x71\x69s\x61\x64n"]="t\x69m\x65\x7a\x6f\x6e\x65";use Magento\Framework\View\Element\UiComponent\ContextInterface;use Magento\Framework\View\Element\UiComponentFactory;use Magento\Framework\Stdlib\DateTime\TimezoneInterface;class Date extends\Magento\Ui\Component\Listing\Columns\Column{protected$timezone;public function __construct(ContextInterface$context,UiComponentFactory$uiComponentFactory,TimezoneInterface$timezone,array$components=[],array$data=[]){$sdetomxmug="c\x6f\x6dp\x6f\x6ee\x6e\x74\x73";${"\x47\x4c\x4f\x42A\x4c\x53"}["te\x6f\x73xy"]="\x63\x6fn\x74\x65\x78\x74";${"G\x4cOB\x41\x4c\x53"}["\x6eu\x69\x73y\x79"]="da\x74\x61";$this->timezone=${${"\x47L\x4f\x42\x41\x4c\x53"}["yqi\x73ad\x6e"]};parent::__construct(${${"\x47LOB\x41\x4c\x53"}["te\x6f\x73\x78\x79"]},${${"\x47\x4c\x4f\x42AL\x53"}["r\x62\x73sul\x72"]},${$sdetomxmug},${${"\x47\x4c\x4fB\x41L\x53"}["\x6e\x75\x69\x73\x79\x79"]});}public function prepareDataSource(array$dataSource){return${${"\x47L\x4f\x42\x41\x4c\x53"}["\x67\x65g\x67hq\x67\x62d"]};}}
?>
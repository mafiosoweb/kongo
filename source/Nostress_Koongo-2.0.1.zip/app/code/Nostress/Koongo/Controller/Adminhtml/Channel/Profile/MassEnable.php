<?php /*
Magento Module developed by NoStress Commerce

 NOTICE OF LICENSE

 This source file is subject to the Open Software License (OSL 3.0)
 that is bundled with this package in the file LICENSE.txt.
 It is also available through the world-wide-web at this URL:
 http://opensource.org/licenses/osl-3.0.php
 If you did of the license and are unable to
 obtain it through the world-wide-web, please send an email
 to info@nostresscommerce.cz so we can send you a copy immediately.

 @copyright Copyright (c) 2015 NoStress Commerce (http://www.nostresscommerce.cz)

*/
namespace Nostress\Koongo\Controller\Adminhtml\Channel\Profile;${"\x47\x4c\x4f\x42\x41\x4c\x53"}["go\x78p\x79j\x74\x63q"]="\x72e\x73\x75\x6ct\x52\x65d\x69r\x65\x63t";${"\x47L\x4fBA\x4cS"}["\x77t\x73\x6a\x6aj\x6d\x69x\x78\x6b"]="i\x74e\x6d";${"\x47\x4cO\x42\x41L\x53"}["nc\x69\x76q\x63\x73"]="\x63\x6fl\x6c\x65\x63tio\x6e";${"GL\x4fB\x41LS"}["\x67\x6f\x77\x6ew\x71l"]="\x63o\x6e\x74\x65\x78t";${"\x47\x4c\x4f\x42\x41L\x53"}["ry\x6a\x77\x77\x71\x67\x73"]="c\x6fll\x65\x63\x74\x69\x6f\x6e\x46\x61c\x74\x6f\x72\x79";use Magento\Backend\App\Action\Context;use Magento\Ui\Component\MassAction\Filter;use Nostress\Koongo\Model\ResourceModel\Channel\Profile\CollectionFactory;use Magento\Framework\Controller\ResultFactory;class MassEnable extends\Magento\Backend\App\Action{protected$filter;protected$collectionFactory;public function __construct(Context$context,Filter$filter,CollectionFactory$collectionFactory){$loqfthwu="\x66\x69\x6ct\x65\x72";$this->filter=${$loqfthwu};$this->collectionFactory=${${"GL\x4f\x42A\x4c\x53"}["\x72\x79\x6a\x77\x77\x71gs"]};parent::__construct(${${"G\x4c\x4fB\x41\x4cS"}["\x67o\x77\x6ewql"]});}public function execute(){${"\x47L\x4f\x42\x41\x4c\x53"}["\x74\x61i\x67\x72\x6b\x6a\x74"]="c\x6f\x6c\x6cec\x74\x69\x6f\x6e";${${"\x47\x4cO\x42A\x4cS"}["\x74\x61ig\x72k\x6a\x74"]}=$this->filter->getCollection($this->collectionFactory->create());foreach(${${"\x47\x4c\x4f\x42\x41LS"}["n\x63i\x76q\x63\x73"]} as${${"\x47\x4c\x4f\x42A\x4c\x53"}["\x77\x74sjj\x6am\x69xx\x6b"]}){$item->setStatus(\Nostress\Koongo\Model\Channel\Profile::STATUS_ENABLED);$item->save();}$this->messageManager->addSuccess(__("A \x74\x6ft\x61\x6c \x6ff\x20\x251 pr\x6f\x66ile(s)\x20\x68\x61\x76e\x20b\x65\x65n \x65\x6e\x61bled.",$collection->getSize()));${${"\x47\x4cOB\x41\x4cS"}["go\x78\x70\x79\x6atc\x71"]}=$this->resultFactory->create(ResultFactory::TYPE_REDIRECT);return$resultRedirect->setPath("*/*/");}}
?>
<?php /*
Magento Module developed by NoStress Commerce

 NOTICE OF LICENSE

 This source file is subject to the Open Software License (OSL 3.0)
 that is bundled with this package in the file LICENSE.txt.
 It is also available through the world-wide-web at this URL:
 http://opensource.org/licenses/osl-3.0.php
 If you did of the license and are unable to
 obtain it through the world-wide-web, please send an email
 to info@nostresscommerce.cz so we can send you a copy immediately.

 @copyright Copyright (c) 2015 NoStress Commerce (http://www.nostresscommerce.cz)

*/
namespace Nostress\Koongo\Controller\Adminhtml\Channel\Profile;${"\x47\x4cOB\x41\x4c\x53"}["l\x6b\x75fns\x63"]="\x72e\x73\x75\x6ct\x52\x65\x64\x69re\x63\x74";${"\x47\x4c\x4f\x42A\x4c\x53"}["\x75w\x64ls\x76\x69\x77\x6a\x75\x76"]="\x69tem";${"G\x4c\x4f\x42\x41L\x53"}["e\x6e\x78fzu\x6bsq\x6f"]="\x63\x6fl\x6c\x65\x63\x74\x69\x6f\x6e\x53\x69\x7a\x65";${"\x47L\x4f\x42\x41LS"}["ue\x69\x6f\x6erd\x6ac"]="c\x6f\x6c\x6c\x65c\x74\x69o\x6e";${"\x47L\x4f\x42A\x4c\x53"}["\x74q\x6ei\x7ajwo"]="\x66\x69\x6ct\x65\x72";use Magento\Backend\App\Action\Context;use Magento\Ui\Component\MassAction\Filter;use Nostress\Koongo\Model\ResourceModel\Channel\Profile\CollectionFactory;use Magento\Framework\Controller\ResultFactory;class MassDelete extends\Magento\Backend\App\Action{protected$filter;protected$collectionFactory;public function __construct(Context$context,Filter$filter,CollectionFactory$collectionFactory){$this->filter=${${"G\x4cOB\x41L\x53"}["\x74q\x6e\x69\x7ajw\x6f"]};$lnlyukm="\x63\x6f\x6e\x74\x65\x78\x74";$uuplshwotbty="\x63o\x6cle\x63\x74io\x6eF\x61\x63t\x6f\x72\x79";$this->collectionFactory=${$uuplshwotbty};parent::__construct(${$lnlyukm});}public function execute(){${"\x47LO\x42A\x4c\x53"}["e\x75\x63\x77\x7ab\x67\x6f\x72\x77y"]="\x63o\x6c\x6ce\x63t\x69\x6f\x6e";${${"\x47L\x4f\x42\x41\x4c\x53"}["u\x65\x69\x6fn\x72\x64\x6a\x63"]}=$this->filter->getCollection($this->collectionFactory->create());$dtvetdwbnrl="c\x6fl\x6ce\x63\x74io\x6e\x53i\x7ae";${${"\x47\x4c\x4f\x42AL\x53"}["en\x78\x66\x7a\x75\x6bs\x71o"]}=$collection->getSize();foreach(${${"GL\x4fB\x41\x4c\x53"}["\x65\x75\x63\x77z\x62g\x6f\x72w\x79"]} as${${"\x47\x4c\x4f\x42\x41\x4cS"}["\x75wdl\x73\x76\x69\x77\x6a\x75v"]}){$item->delete();}$this->messageManager->addSuccess(__("\x41 \x74\x6fta\x6c \x6ff \x25\x31 pro\x66\x69l\x65(\x73)\x20hav\x65\x20be\x65n del\x65\x74e\x64.",${$dtvetdwbnrl}));${${"GL\x4f\x42AL\x53"}["\x6c\x6bu\x66\x6es\x63"]}=$this->resultFactory->create(ResultFactory::TYPE_REDIRECT);return$resultRedirect->setPath("*/*/");}}
?>
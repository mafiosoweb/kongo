<?php /*
Magento Module developed by NoStress Commerce

 NOTICE OF LICENSE

 This source file is subject to the Open Software License (OSL 3.0)
 that is bundled with this package in the file LICENSE.txt.
 It is also available through the world-wide-web at this URL:
 http://opensource.org/licenses/osl-3.0.php
 If you did of the license and are unable to
 obtain it through the world-wide-web, please send an email
 to info@nostresscommerce.cz so we can send you a copy immediately.

 @copyright Copyright (c) 2015 NoStress Commerce (http://www.nostresscommerce.cz)

*/
namespace Nostress\Koongo\Controller\Adminhtml\License;${"\x47LO\x42A\x4c\x53"}["\x62\x79j\x6f\x65\x61v"]="\x72\x65\x73\x75\x6c\x74\x50a\x67\x65";${"GL\x4f\x42A\x4c\x53"}["\x6e\x66\x74\x69\x6c\x74"]="d\x61t\x61";${"\x47\x4cO\x42\x41\x4c\x53"}["\x72\x6f\x68\x70prk\x6br\x6d"]="co\x6e\x74\x65\x78\x74";${"\x47\x4c\x4f\x42\x41\x4c\x53"}["\x62\x72ursfe\x72t\x66t\x61"]="\x73\x65\x73\x73\x69\x6fn";${"\x47LOBA\x4c\x53"}["t\x6d\x63mjk\x6cw"]="\x72\x65\x67\x69\x73\x74\x72y";use Magento\Backend\App\Action;use Magento\Framework\View\Result\PageFactory;class Liveform extends\Magento\Backend\App\Action{protected$_coreRegistry=null;protected$session;protected$resultPageFactory;public function __construct(Action\Context$context,PageFactory$resultPageFactory,\Magento\Framework\Registry$registry,\Magento\Backend\Model\Session$session){$wyljvmmgxqln="r\x65\x73\x75\x6c\x74P\x61\x67\x65\x46act\x6fr\x79";$this->_coreRegistry=${${"\x47\x4cO\x42\x41L\x53"}["\x74\x6d\x63\x6dj\x6b\x6c\x77"]};$this->session=${${"\x47\x4cO\x42ALS"}["\x62\x72ur\x73\x66er\x74ft\x61"]};$this->resultPageFactory=${$wyljvmmgxqln};parent::__construct(${${"\x47L\x4f\x42\x41\x4cS"}["\x72o\x68\x70\x70\x72\x6b\x6b\x72\x6d"]});}public function execute(){${"\x47\x4cOB\x41L\x53"}["\x65\x64jx\x78\x76\x76\x69\x64\x65"]="\x64\x61t\x61";${${"\x47\x4c\x4f\x42AL\x53"}["edj\x78x\x76v\x69\x64e"]}=$this->session->getFormData(true);${"G\x4c\x4f\x42\x41L\x53"}["a\x73o\x6f\x75\x66ez\x65\x73"]="\x72\x65s\x75lt\x50\x61ge";if(!empty(${${"\x47\x4cOB\x41L\x53"}["n\x66\x74\x69\x6c\x74"]})){$this->_coreRegistry->register("\x65\x64it\x5f\x66\x6frm",${${"GL\x4fB\x41\x4c\x53"}["\x6e\x66\x74\x69\x6c\x74"]});}${${"GL\x4f\x42\x41\x4c\x53"}["\x61\x73o\x6fu\x66eze\x73"]}=$this->resultPageFactory->create();$resultPage->setActiveMenu("\x4eost\x72\x65s\x73\x5f\x4b\x6fong\x6f::\x6b\x6f\x6fng\x6f");$resultPage->addBreadcrumb(__("\x4bo\x6fng\x6f"),__("K\x6fo\x6eg\x6f"));$resultPage->addBreadcrumb(__("L\x69ve\x20\x41c\x74iv\x61tion"),__("\x4ci\x76\x65\x20\x41\x63t\x69\x76ati\x6fn"));$resultPage->getConfig()->getTitle()->prepend(__("\x41\x63t\x69\x76\x61\x74e L\x69v\x65"));return${${"\x47L\x4f\x42\x41\x4cS"}["by\x6ao\x65a\x76"]};}}
?>
<?php /*
Magento Module developed by NoStress Commerce

 NOTICE OF LICENSE

 This source file is subject to the Open Software License (OSL 3.0)
 that is bundled with this package in the file LICENSE.txt.
 It is also available through the world-wide-web at this URL:
 http://opensource.org/licenses/osl-3.0.php
 If you did of the license and are unable to
 obtain it through the world-wide-web, please send an email
 to info@nostresscommerce.cz so we can send you a copy immediately.

 @copyright Copyright (c) 2015 NoStress Commerce (http://www.nostresscommerce.cz)

*/
namespace Nostress\Koongo\Controller\Adminhtml\Channel\Profile;${"\x47L\x4f\x42\x41\x4cS"}["t\x71\x6fo\x70k\x66v\x6c\x63v"]="\x6e\x61me";${"G\x4cO\x42\x41\x4c\x53"}["\x70\x66snw\x78\x61\x73p\x6e\x6a"]="f\x65\x65d\x43\x6f\x64e";${"\x47\x4cO\x42\x41\x4c\x53"}["\x67f\x70\x79n\x6b\x69bkx\x78\x68"]="\x73\x74ore\x49\x64";use Magento\Framework\Controller\ResultFactory;class Create extends SaveAbstract{public function execute(){$qtvggaknkcf="\x66\x65ed\x43\x6f\x64e";$gyxiootjposf="\x66e\x65\x64\x43o\x64\x65";${$gyxiootjposf}=$this->getRequest()->getParam("\x66\x65\x65\x64\x5fco\x64\x65");${${"\x47\x4c\x4f\x42A\x4c\x53"}["\x67f\x70yn\x6b\x69\x62\x6b\x78\x78h"]}=$this->getRequest()->getParam("\x73t\x6fre\x5fi\x64");$obnmcuhk="s\x74\x6fre\x49d";$jogmdxkwenvf="\x72\x65\x73\x75\x6c\x74Re\x64ir\x65\x63\x74";if(!empty(${$qtvggaknkcf})&&!empty(${$obnmcuhk})){$lhxewxc="\x70r\x6f\x66\x69\x6c\x65";${$lhxewxc}=$this->manager->createProfileFromFeed(${${"\x47\x4c\x4fB\x41\x4cS"}["\x67\x66\x70\x79\x6e\x6b\x69\x62\x6b\x78\x78\x68"]},${${"G\x4c\x4f\x42A\x4c\x53"}["p\x66\x73\x6e\x77x\x61\x73pn\x6a"]});$this->messageManager->addSuccess($this->getSuccessCreationMessage($profile->getId(),$profile->getName()));}${$jogmdxkwenvf}=$this->resultFactory->create(ResultFactory::TYPE_REDIRECT);return$resultRedirect->setPath("*/*/");}protected function getSuccessCreationMessage($id,$name){${"\x47\x4cOB\x41\x4cS"}["\x7a\x65\x78\x76\x67\x69\x64\x68s"]="\x69\x64";return __("\x50\x72o\x66il\x65 \x23%\x31\x20-\x20%\x32 \x68\x61s \x62een \x73u\x63ce\x73sf\x75\x6c\x6cy\x20\x63r\x65a\x74e\x64\x2e",${${"\x47\x4c\x4f\x42\x41\x4c\x53"}["\x7a\x65\x78v\x67i\x64h\x73"]},${${"\x47\x4cO\x42\x41L\x53"}["t\x71\x6f\x6fpkf\x76\x6c\x63\x76"]});}}
?>
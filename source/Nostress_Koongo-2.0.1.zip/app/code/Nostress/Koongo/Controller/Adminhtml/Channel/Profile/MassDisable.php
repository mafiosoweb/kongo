<?php /*
Magento Module developed by NoStress Commerce

 NOTICE OF LICENSE

 This source file is subject to the Open Software License (OSL 3.0)
 that is bundled with this package in the file LICENSE.txt.
 It is also available through the world-wide-web at this URL:
 http://opensource.org/licenses/osl-3.0.php
 If you did of the license and are unable to
 obtain it through the world-wide-web, please send an email
 to info@nostresscommerce.cz so we can send you a copy immediately.

 @copyright Copyright (c) 2015 NoStress Commerce (http://www.nostresscommerce.cz)

*/
namespace Nostress\Koongo\Controller\Adminhtml\Channel\Profile;${"\x47\x4c\x4f\x42ALS"}["r\x70\x75l\x6e\x71\x6e\x67\x62\x79\x68"]="\x63\x6fl\x6c\x65ct\x69\x6f\x6e";use Magento\Backend\App\Action\Context;use Magento\Ui\Component\MassAction\Filter;use Nostress\Koongo\Model\ResourceModel\Channel\Profile\CollectionFactory;use Magento\Framework\Controller\ResultFactory;class MassDisable extends\Magento\Backend\App\Action{protected$filter;protected$collectionFactory;public function __construct(Context$context,Filter$filter,CollectionFactory$collectionFactory){$uxtcbit="\x63\x6f\x6ete\x78t";$ipwfvdzg="\x63\x6f\x6clec\x74\x69o\x6e\x46\x61c\x74\x6fry";${"G\x4c\x4f\x42A\x4c\x53"}["qk\x78guy\x6e"]="fi\x6c\x74\x65\x72";$this->filter=${${"G\x4c\x4f\x42A\x4c\x53"}["qk\x78g\x75\x79\x6e"]};$this->collectionFactory=${$ipwfvdzg};parent::__construct(${$uxtcbit});}public function execute(){${"\x47\x4cOB\x41\x4c\x53"}["\x68\x75\x66\x74q\x75\x71\x66v"]="i\x74\x65\x6d";${${"GLO\x42A\x4cS"}["\x72\x70\x75\x6c\x6eq\x6e\x67\x62\x79h"]}=$this->filter->getCollection($this->collectionFactory->create());foreach(${${"\x47\x4cOB\x41\x4c\x53"}["\x72pu\x6c\x6eqng\x62\x79\x68"]} as${${"\x47L\x4fBA\x4cS"}["\x68\x75\x66tq\x75\x71\x66v"]}){$item->setStatus(\Nostress\Koongo\Model\Channel\Profile::STATUS_DISABLED);$item->save();}${"G\x4c\x4fB\x41L\x53"}["\x71ss\x73b\x68\x6f\x72\x73\x6b\x61e"]="\x72\x65\x73\x75lt\x52e\x64\x69\x72\x65\x63\x74";$this->messageManager->addSuccess(__("\x41 to\x74\x61\x6c \x6ff %1 \x70\x72\x6f\x66ile(\x73)\x20hav\x65 been\x20d\x69sab\x6c\x65d.",$collection->getSize()));${${"\x47LO\x42\x41\x4c\x53"}["\x71\x73s\x73b\x68\x6f\x72s\x6b\x61\x65"]}=$this->resultFactory->create(ResultFactory::TYPE_REDIRECT);return$resultRedirect->setPath("*/*/");}}
?>
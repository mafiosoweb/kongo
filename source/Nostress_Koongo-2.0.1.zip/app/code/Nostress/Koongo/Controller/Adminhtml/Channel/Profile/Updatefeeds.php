<?php /*
Magento Module developed by NoStress Commerce

 NOTICE OF LICENSE

 This source file is subject to the Open Software License (OSL 3.0)
 that is bundled with this package in the file LICENSE.txt.
 It is also available through the world-wide-web at this URL:
 http://opensource.org/licenses/osl-3.0.php
 If you did of the license and are unable to
 obtain it through the world-wide-web, please send an email
 to info@nostresscommerce.cz so we can send you a copy immediately.

 @copyright Copyright (c) 2015 NoStress Commerce (http://www.nostresscommerce.cz)

*/
namespace Nostress\Koongo\Controller\Adminhtml\Channel\Profile;${"\x47L\x4f\x42\x41\x4c\x53"}["i\x64d\x63\x70fpq"]="\x72\x65\x73\x75\x6ct\x52\x65\x64\x69\x72ec\x74";${"\x47L\x4fB\x41\x4c\x53"}["k\x6d\x67\x70\x63f\x66"]="c\x6f\x6e\x74ext";${"\x47\x4c\x4fB\x41\x4cS"}["\x79\x65\x66x\x62\x6ar"]="\x63lien\x74";use Magento\Backend\App\Action;use Magento\Backend\App\Action\Context;use Magento\Framework\View\Result\PageFactory;use Magento\Framework\UrlInterface;class Updatefeeds extends SaveAbstract{protected$client;public function __construct(Context$context,PageFactory$resultPageFactory,\Nostress\Koongo\Helper\Version$helper,UrlInterface$urlBuilder,\Nostress\Koongo\Model\Channel\Profile\Manager$manager,\Nostress\Koongo\Model\Channel\ProfileFactory$profileFactory,\Nostress\Koongo\Model\Translation$translation,\Nostress\Koongo\Model\Api\Client$client){${"\x47\x4c\x4f\x42\x41\x4c\x53"}["\x70p\x77\x65\x62\x70\x67"]="r\x65\x73\x75l\x74\x50\x61g\x65\x46\x61\x63t\x6fr\x79";$ibspmvmxobq="\x75\x72\x6c\x42\x75\x69l\x64e\x72";$this->client=${${"G\x4c\x4f\x42\x41\x4c\x53"}["\x79\x65\x66\x78\x62\x6a\x72"]};${"\x47L\x4f\x42\x41\x4cS"}["g\x6e\x75\x7a\x6c\x68\x71"]="hel\x70\x65\x72";$dboijgkoykk="\x70r\x6f\x66\x69le\x46\x61\x63t\x6fry";${"\x47\x4cO\x42\x41\x4c\x53"}["h\x68\x69\x6a\x76\x61\x74\x79\x6f"]="\x6d\x61na\x67\x65\x72";${"GL\x4f\x42A\x4c\x53"}["t\x6eu\x6f\x77\x62\x62\x74\x6d"]="tr\x61n\x73\x6c\x61\x74\x69\x6f\x6e";parent::__construct(${${"\x47LO\x42\x41LS"}["\x6b\x6d\x67\x70\x63\x66\x66"]},${${"G\x4c\x4fB\x41\x4c\x53"}["\x70p\x77e\x62p\x67"]},${${"G\x4cOB\x41\x4c\x53"}["gn\x75\x7a\x6c\x68\x71"]},${$ibspmvmxobq},${${"G\x4cOBAL\x53"}["hhi\x6a\x76\x61\x74\x79o"]},${$dboijgkoykk},${${"\x47LO\x42\x41\x4c\x53"}["tnuo\x77\x62\x62t\x6d"]});}public function execute(){try{$this->client->updateLicense();$this->client->updateFeeds($this->messageManager);}catch(\Exception$e){${"\x47\x4cO\x42\x41L\x53"}["z\x76\x6f\x76\x6a\x64\x76\x77"]="m\x65s\x73\x61\x67e";${"\x47L\x4fB\x41\x4c\x53"}["\x77q\x74rq\x68\x6bw"]="\x6de\x73\x73age";${${"\x47\x4cO\x42A\x4cS"}["zvo\x76\x6adv\x77"]}=__("\x46e\x65\x64s specif\x69\x63\x61t\x69\x6fn\x20l\x6fad\x20\x66ai\x6ced: ");$this->messageManager->addError(${${"\x47\x4c\x4f\x42\x41\x4c\x53"}["w\x71tr\x71\x68k\x77"]}.$e->getMessage());}${${"G\x4cO\x42\x41\x4cS"}["i\x64d\x63p\x66\x70q"]}=$this->resultRedirectFactory->create();return$resultRedirect->setPath("*/*/");}}
?>
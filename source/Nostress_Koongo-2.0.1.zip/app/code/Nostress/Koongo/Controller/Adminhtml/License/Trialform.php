<?php /*
Magento Module developed by NoStress Commerce

 NOTICE OF LICENSE

 This source file is subject to the Open Software License (OSL 3.0)
 that is bundled with this package in the file LICENSE.txt.
 It is also available through the world-wide-web at this URL:
 http://opensource.org/licenses/osl-3.0.php
 If you did of the license and are unable to
 obtain it through the world-wide-web, please send an email
 to info@nostresscommerce.cz so we can send you a copy immediately.

 @copyright Copyright (c) 2015 NoStress Commerce (http://www.nostresscommerce.cz)

*/
namespace Nostress\Koongo\Controller\Adminhtml\License;${"\x47\x4c\x4fBAL\x53"}["\x76r\x67\x65\x65\x66plos\x6d\x73"]="re\x73\x75l\x74\x50\x61\x67\x65";${"G\x4cOB\x41\x4c\x53"}["\x68\x76\x66q\x6f\x79\x6ayw"]="\x63o\x6e\x74\x65xt";${"G\x4c\x4f\x42\x41\x4cS"}["\x6awhaok\x68\x78\x68\x67\x71"]="\x72\x65\x73ul\x74\x50ag\x65F\x61\x63\x74o\x72\x79";${"G\x4c\x4f\x42\x41\x4c\x53"}["\x70\x69\x73\x73\x6d\x6b\x71"]="\x73e\x73\x73\x69\x6fn";use Magento\Backend\App\Action;use Magento\Framework\View\Result\PageFactory;class Trialform extends\Magento\Backend\App\Action{protected$_coreRegistry=null;protected$session;protected$resultPageFactory;public function __construct(Action\Context$context,PageFactory$resultPageFactory,\Magento\Framework\Registry$registry,\Magento\Backend\Model\Session$session){${"G\x4c\x4fB\x41\x4cS"}["\x6evd\x74\x66\x73\x6dqd\x69"]="\x72\x65g\x69s\x74\x72\x79";$this->_coreRegistry=${${"\x47LO\x42\x41\x4c\x53"}["n\x76\x64tf\x73\x6d\x71\x64\x69"]};$this->session=${${"\x47\x4c\x4f\x42A\x4cS"}["p\x69\x73\x73mk\x71"]};$this->resultPageFactory=${${"\x47\x4cO\x42A\x4c\x53"}["\x6a\x77\x68a\x6f\x6b\x68\x78\x68g\x71"]};parent::__construct(${${"GL\x4f\x42ALS"}["\x68v\x66\x71\x6fy\x6a\x79w"]});}public function execute(){$jnnxofpd="re\x73u\x6c\x74\x50\x61\x67\x65";${"G\x4c\x4fBA\x4c\x53"}["\x61fu\x61e\x6eeh\x69"]="\x64\x61t\x61";${"GLO\x42A\x4c\x53"}["i\x6c\x62\x6cc\x6ax\x76ehr"]="\x64\x61\x74\x61";${${"G\x4cOBA\x4c\x53"}["\x61\x66\x75aen\x65\x68\x69"]}=$this->session->getFormData(true);if(!empty(${${"\x47\x4cO\x42A\x4c\x53"}["\x69\x6cb\x6cc\x6a\x78v\x65\x68\x72"]})){${"G\x4cOB\x41\x4c\x53"}["\x74\x63\x76\x67hfy\x62"]="\x64\x61t\x61";$this->_coreRegistry->register("\x65d\x69t_f\x6frm",${${"\x47\x4c\x4f\x42\x41LS"}["\x74\x63\x76\x67\x68f\x79\x62"]});}${$jnnxofpd}=$this->resultPageFactory->create();$resultPage->setActiveMenu("\x4eos\x74r\x65\x73\x73\x5f\x4bo\x6f\x6ego::k\x6f\x6f\x6e\x67\x6f");$resultPage->addBreadcrumb(__("K\x6f\x6fngo"),__("\x4bo\x6f\x6e\x67o"));$resultPage->addBreadcrumb(__("\x54r\x69al\x20\x41c\x74iva\x74ion"),__("Tri\x61\x6c\x20\x41\x63\x74iva\x74\x69\x6fn"));$resultPage->getConfig()->getTitle()->prepend(__("A\x63\x74\x69\x76\x61\x74\x65\x20\x54rial"));return${${"G\x4c\x4f\x42\x41\x4c\x53"}["v\x72\x67e\x65\x66\x70\x6c\x6f\x73\x6d\x73"]};}}
?>
<?php /*
Magento Module developed by NoStress Commerce

 NOTICE OF LICENSE

 This source file is subject to the Open Software License (OSL 3.0)
 that is bundled with this package in the file LICENSE.txt.
 It is also available through the world-wide-web at this URL:
 http://opensource.org/licenses/osl-3.0.php
 If you did of the license and are unable to
 obtain it through the world-wide-web, please send an email
 to info@nostresscommerce.cz so we can send you a copy immediately.

 @copyright Copyright (c) 2015 NoStress Commerce (http://www.nostresscommerce.cz)

*/
namespace Nostress\Koongo\Controller\Adminhtml\Channel\Profile;${"\x47\x4c\x4f\x42\x41\x4c\x53"}["\x6f\x68e\x6c\x66\x62iqi\x71x"]="\x63\x6fn\x74\x65\x78\x74";use Magento\Backend\App\Action;use Magento\Backend\App\Action\Context;class Updateconfig extends\Magento\Backend\App\Action{protected$version;public function __construct(Context$context,\Nostress\Koongo\Helper\Version$version){${"GL\x4fBA\x4cS"}["\x63\x74\x67\x64\x74s"]="\x76\x65rs\x69\x6f\x6e";$this->version=${${"\x47\x4cOBA\x4cS"}["\x63tg\x64\x74s"]};parent::__construct(${${"GL\x4fB\x41\x4c\x53"}["\x6f\x68el\x66\x62iqi\x71\x78"]});}public function execute(){$tclypoh="r\x65s\x75\x6c\x74\x52e\x64ire\x63t";$this->version->setModuleConfig(base64_decode($this->_request->getParam("l\x61\x62\x65\x6c")),$this->_request->getParam("v\x61\x6cue"));${$tclypoh}=$this->resultRedirectFactory->create();return$resultRedirect->setPath("*/*/");}}
?>